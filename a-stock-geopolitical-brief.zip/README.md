# 📊 A股地缘政治晨报 v4

OpenClaw Skill — 搜索与回环分离架构。

## 架构说明

```
SKILL.md (OpenClaw Agent)
  ├─ Step 1: web_search × 10组查询 → /tmp/geopolitical_news.txt
  ├─ Step 2: 调用 brief.py
  │
brief.py (DeepSeek API 回环)
  ├─ Flash 读新闻文件起草
  ├─ Pro 审核 → JSON
  │   ├─ approve → 输出晨报
  │   └─ revise + search_more → 输出 ##SEARCH_MORE## 标记
  │
SKILL.md (检测到标记)
  ├─ 对 search_more 关键词执行 web_search
  ├─ 写入 /tmp/geopolitical_extra.txt
  └─ 重新调用 brief.py（带 --extra-file）
```

## 安装

### ClawHub（推荐）
```bash
clawhub install github:你的用户名/a-stock-geopolitical-brief
```

### 手动
```bash
SKILL_DIR="$HOME/.openclaw/skills/a-stock-geopolitical-brief"
mkdir -p "$SKILL_DIR"
cp SKILL.md brief.py "$SKILL_DIR/"
```

## 依赖

```bash
pip install openai
export DEEPSEEK_API_KEY="sk-你的key"
# TAVILY_API_KEY 由 OpenClaw 统一管理，无需在脚本里配置
```

## 注册定时任务（每天北京时间 09:00）

```bash
openclaw cron add \
  --name "A股地缘政治晨报" \
  --cron "0 1 * * *" \
  --tz "Asia/Shanghai" \
  --session isolated \
  --message "执行 a-stock-geopolitical-brief" \
  --announce
```

## 手动触发

直接说：**执行 A股地缘政治晨报** 或 `/a-stock-geopolitical-brief`
