# A股地缘政治晨报

OpenClaw Skill — 每天搜集过去24小时全球地缘政治事件，筛选对A股有实质影响的内容，经 deepseek-v4-flash 起草、deepseek-v4-pro 审核（最多2轮回环）后直接推送晨报。

## 安装

### 方式 A：通过 ClawHub（推荐）

```bash
clawhub install github:你的用户名/a-stock-geopolitical-brief
```

### 方式 B：手动安装

```bash
SKILL_DIR="$HOME/.openclaw/skills/a-stock-geopolitical-brief"
mkdir -p "$SKILL_DIR"
curl -o "$SKILL_DIR/SKILL.md" https://raw.githubusercontent.com/你的用户名/a-stock-geopolitical-brief/main/SKILL.md
curl -o "$SKILL_DIR/brief.py"  https://raw.githubusercontent.com/你的用户名/a-stock-geopolitical-brief/main/brief.py
```

## 依赖

```bash
pip install openai
export DEEPSEEK_API_KEY="sk-你的key"
```

## 注册定时任务（每天北京时间09:00）

```bash
openclaw cron add \
  --name "A股地缘政治晨报" \
  --cron "0 1 * * *" \
  --tz "Asia/Shanghai" \
  --session isolated \
  --message "执行 a-stock-geopolitical-brief" \
  --announce
```

## 手动触发

直接对 OpenClaw 说：**执行 A股地缘政治晨报** 或 `/a-stock-geopolitical-brief`

## 文件说明

| 文件 | 作用 |
|------|------|
| `SKILL.md` | OpenClaw Skill 入口，声明元数据和执行指令 |
| `brief.py` | 核心编排脚本，直调 DeepSeek API，自管回环逻辑 |
