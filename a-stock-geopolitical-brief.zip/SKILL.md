---
name: a-stock-geopolitical-brief
description: A股地缘政治晨报。deepseek-v4-flash起草，deepseek-v4-pro审核，自动回环最多2轮，审核通过后直接输出，无需用户确认。
metadata: {"openclaw":{"requires":{"bins":["python3"],"env":["DEEPSEEK_API_KEY"]},"primaryEnv":"DEEPSEEK_API_KEY","emoji":"📊"}}
user-invocable: true
---

# A股地缘政治晨报

执行步骤：

1. 运行命令：`python3 {baseDir}/brief.py`
2. 将脚本的完整 stdout 输出原样呈现给用户，不裁剪、不改写
3. 若脚本报错（如缺少 openai 库），提示用户执行：`pip install openai`，然后重试
4. 若报错提示 DEEPSEEK_API_KEY 未设置，提示用户执行：`export DEEPSEEK_API_KEY='sk-你的key'`

无需用户确认，直接执行并输出。
