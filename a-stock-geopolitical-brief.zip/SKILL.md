---
name: a-stock-geopolitical-brief
description: A股地缘政治晨报。Agent负责web_search实时搜索，brief.py负责Flash/Pro回环，Pro可触发补充搜索，审核通过后直接输出，无需用户确认。
metadata: {"openclaw":{"requires":{"bins":["python3"],"env":["DEEPSEEK_API_KEY"]},"primaryEnv":"DEEPSEEK_API_KEY","emoji":"📊"}}
user-invocable: true
---

# A股地缘政治晨报

## 完整执行流程

### Step 1：实时搜索（你负责调用 web_search）

依次执行以下搜索查询，将所有结果拼合成新闻文本，写入 `/tmp/geopolitical_news.txt`：

搜索关键词列表：
1. `China US trade tariffs sanctions latest 24 hours`
2. `Taiwan Strait South China Sea military news today`
3. `Russia Ukraine war energy supply latest`
4. `Middle East conflict oil price today`
5. `North Korea military provocation latest`
6. `Federal Reserve ECB interest rate statement latest`
7. `中美关税制裁贸易摩擦 最新`
8. `台海南海军事动态 最新`
9. `涉华外交 G7 联合国 最新`
10. `全球供应链中断 最新`

拼合格式：
```
### 搜索：[查询关键词]
- [标题]：[摘要内容]
- [标题]：[摘要内容]
...
```

将拼合结果写入文件：
```bash
cat > /tmp/geopolitical_news.txt << 'EOF'
[拼合的新闻内容]
EOF
```

### Step 2：调用 brief.py 执行 Flash→Pro 回环

```bash
python3 {baseDir}/brief.py --news-file /tmp/geopolitical_news.txt
```

### Step 3：检测输出中是否有补充搜索标记

检查 brief.py 的输出中是否包含以下格式的标记：
```
##SEARCH_MORE##关键词1|关键词2|关键词3##END##
```

**如果有补充搜索标记**：
1. 提取 `##SEARCH_MORE##` 和 `##END##` 之间的内容，按 `|` 分割得到关键词列表
2. 对每个关键词执行 web_search，将新结果写入 `/tmp/geopolitical_extra.txt`
3. 重新调用 brief.py，传入补充文件：
   ```bash
   python3 {baseDir}/brief.py \
     --news-file /tmp/geopolitical_news.txt \
     --extra-file /tmp/geopolitical_extra.txt
   ```

**如果没有补充搜索标记**：
直接进入 Step 4。

### Step 4：输出最终晨报

将 brief.py 的完整 stdout 输出（去掉 `##SEARCH_MORE##...##END##` 标记行）原样呈现给用户，不裁剪、不改写。

## 错误处理

- 若 brief.py 报错缺少依赖：提示用户执行 `pip install openai`
- 若报错缺少 DEEPSEEK_API_KEY：提示用户执行 `export DEEPSEEK_API_KEY='sk-你的key'`
- 若 web_search 无结果：在 `/tmp/geopolitical_news.txt` 写入 `（搜索无结果，请基于模型知识起草）`，继续执行

## 执行要求

- 无需用户确认，直接执行并输出
- 整个流程包括搜索、回环、补搜在内，完成后直接推送最终晨报
