#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股地缘政治晨报 编排脚本
模型: deepseek-v4-flash (起草/修改) + deepseek-v4-pro (审核)
自管 Flash->Pro 回环，stdout 输出最终晨报，由 OpenClaw 转发给用户
"""

import os
import json
import sys
import datetime
from openai import OpenAI

# ═══════════════════════════════════════════════════════════════════
#  配置区 — 只需改这里
# ═══════════════════════════════════════════════════════════════════
API_KEY      = os.environ.get("DEEPSEEK_API_KEY", "")
BASE_URL     = "https://api.deepseek.com"
MODEL_FLASH  = "deepseek-v4-flash"
MODEL_PRO    = "deepseek-v4-pro"
MAX_ROUNDS   = 2        # 最大审核回环次数
PRO_THINKING = "high"  # Pro 思考强度: "high" 或 "max"
# ═══════════════════════════════════════════════════════════════════

TZ_CST   = datetime.timezone(datetime.timedelta(hours=8))
now      = datetime.datetime.now(TZ_CST)
date_str = now.strftime("%Y年%m月%d日")

client = OpenAI(api_key=API_KEY, base_url=BASE_URL)

# ── System Prompts ────────────────────────────────────────────────
FLASH_SYSTEM = f"""你是一名专注A股的地缘政治分析师，今天是{date_str}。

任务：搜集过去24小时全球地缘政治事件，严格筛选后起草晨报。

【只保留以下类型的事件，其余全部过滤】
- 中美贸易摩擦、关税、制裁、出口管制
- 台海局势、南海动态
- 俄乌战争（影响能源/粮食/通胀预期的进展）
- 中东局势（影响原油价格的动态）
- 朝鲜半岛动态
- 全球主要央行政策表态（影响风险偏好）
- 涉华国际外交事件（G7/联合国/WTO/APEC等）
- 全球供应链中断事件

无实质影响的事件一律不收录。
若确无重大事件，明确输出：今日无重大地缘政治影响，市场情绪中性。

【严格按以下格式输出，不得添加无关内容】

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 A股地缘政治晨报
{date_str} · 覆盖过去24小时
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【市场情绪总体判断】
利多/中性/利空/混合 — 一句话说明主要驱动因素

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【重要事件】（按影响度从高到低排列）

🔴 高影响
[事件名称]
- 发生时间：
- 核心内容：（不超过100字）
- A股影响：
  · 利多板块：
  · 利空板块：
  · 需关注板块：
- 持续性：短期（1-3天）/中期（1-2周）/长期观察

🟡 中影响
（同上格式）

🟢 低影响
[事件名称]：一句话概括，预计影响有限

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【板块影响矩阵】

| 板块 | 方向 | 逻辑 |
|------|------|------|
（只填有实质影响的板块；↑利多 ↓利空 →中性；无影响的行删除）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【已过滤事件】
（搜索到但对A股无实质影响的事件，一句话概括）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
信源：（主要参考来源）"""

PRO_SYSTEM = """你是A股地缘政治晨报的审核员。
审核草稿，不得重写全文，只输出以下JSON（不要有任何其他内容）：

{
  "verdict": "approve 或 revise",
  "score": 整数0-100,
  "issues": [
    {
      "severity": "high 或 medium 或 low",
      "message": "问题描述",
      "fix": "给Flash的具体修改指令"
    }
  ],
  "must_fix": ["高严重度必须修改项列表，可为空数组"]
}

审核标准：
1. 是否遗漏过去24小时内影响A股的重大地缘政治事件
2. 板块影响判断是否合理，是否存在过度推断
3. 因果链是否有明显逻辑错误
4. 是否混入了对A股无实质影响的噪音事件
5. 市场情绪总体判断是否与事件内容吻合

score >= 80 且无 high 级别 issues → verdict 输出 approve
否则 → verdict 输出 revise"""

FLASH_REVISE_TMPL = """以下是你的晨报草稿，以及审核员的修改意见。
请严格按照 must_fix 和 issues 中的 fix 指令修改，保持原有格式结构，不要修改无问题的部分。

【审核意见 JSON】
{review_json}

【原稿】
{draft}

请输出修改后的完整晨报（保持原始格式）："""

FLASH_INIT = f"请基于你的知识，起草{date_str}的A股地缘政治晨报，覆盖过去24小时的全球地缘政治事件。重点关注：中美关系、台海、南海、俄乌、中东、朝鲜半岛、主要央行政策、涉华外交事件。严格按照系统提示的格式和筛选规则输出。"

# ── API 调用 ──────────────────────────────────────────────────────
def call_flash(messages: list) -> str:
    resp = client.chat.completions.create(
        model=MODEL_FLASH,
        messages=messages,
        temperature=0.3,
        max_tokens=4000,
    )
    return resp.choices[0].message.content.strip()

def call_pro(draft: str) -> dict:
    resp = client.chat.completions.create(
        model=MODEL_PRO,
        messages=[
            {"role": "system", "content": PRO_SYSTEM},
            {"role": "user",   "content": f"请审核以下晨报草稿：\n\n{draft}"},
        ],
        temperature=0.1,
        max_tokens=1500,
        extra_body={"reasoning_effort": PRO_THINKING},
    )
    raw = resp.choices[0].message.content.strip()
    start = raw.find("{")
    end   = raw.rfind("}") + 1
    if start == -1 or end == 0:
        return {"verdict": "approve", "score": 70, "issues": [],
                "must_fix": [], "_raw": raw}
    try:
        return json.loads(raw[start:end])
    except json.JSONDecodeError:
        return {"verdict": "approve", "score": 70, "issues": [],
                "must_fix": [], "_parse_error": raw[start:end]}

# ── 主流程 ────────────────────────────────────────────────────────
def main():
    if not API_KEY:
        print("❌ 错误：未检测到 DEEPSEEK_API_KEY 环境变量")
        print("请执行：export DEEPSEEK_API_KEY='sk-xxxxxxxx'")
        sys.exit(1)

    log = lambda msg: print(msg, flush=True)

    log(f"\n🔄 {date_str} A股地缘政治晨报生成中...\n")

    flash_msgs = [
        {"role": "system", "content": FLASH_SYSTEM},
        {"role": "user",   "content": FLASH_INIT},
    ]
    log("📝 [Flash] 正在起草初稿...")
    draft = call_flash(flash_msgs)
    log(f"   初稿完成，{len(draft)} 字符\n")

    for rnd in range(1, MAX_ROUNDS + 1):
        log(f"🔍 [Pro] 审核中（第 {rnd}/{MAX_ROUNDS} 轮）...")
        review  = call_pro(draft)
        verdict  = review.get("verdict", "approve")
        score    = review.get("score", 0)
        issues   = review.get("issues", [])
        must_fix = review.get("must_fix", [])

        log(f"   verdict={verdict}  score={score}  issues={len(issues)}  must_fix={len(must_fix)}")

        if verdict == "approve":
            log(f"✅ [Pro] 审核通过（第 {rnd} 轮，score={score}）\n")
            break

        if rnd == MAX_ROUNDS:
            log(f"⚠️  已达最大审核轮次（{MAX_ROUNDS}），输出当前版本\n")
            draft += f"\n\n⚠️ 注：已达最大审核轮次（{MAX_ROUNDS} 轮），当前版本未经完整审核，请人工复核"
            break

        log(f"✏️  [Flash] 按审核意见修改中...")
        revise_prompt = FLASH_REVISE_TMPL.replace(
            "{review_json}", json.dumps(review, ensure_ascii=False, indent=2)
        ).replace("{draft}", draft)
        flash_msgs = [
            {"role": "system", "content": FLASH_SYSTEM},
            {"role": "user",   "content": revise_prompt},
        ]
        draft = call_flash(flash_msgs)
        log(f"   修改完成，{len(draft)} 字符\n")

    print("\n" + "═" * 60)
    print(draft)
    print("═" * 60 + "\n")

if __name__ == "__main__":
    main()
