#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股地缘政治晨报 编排脚本 v4
职责：纯 Flash->Pro API 回环，不做搜索
搜索由 OpenClaw Agent (SKILL.md) 负责，通过参数传入

用法：
  # 首次运行（Agent 已把新闻写入临时文件）
  python3 brief.py --news-file /tmp/geopolitical_news.txt

  # 带补搜结果追加运行
  python3 brief.py --news-file /tmp/geopolitical_news.txt --extra-file /tmp/extra_news.txt

输出约定：
  - 正常晨报直接输出到 stdout
  - 如果 Pro 要求补充搜索，在末尾输出特殊标记供 SKILL.md 检测：
    ##SEARCH_MORE##关键词1|关键词2|关键词3##END##
"""

import os, json, sys, datetime, argparse
from openai import OpenAI

# ═══════════════════════════════════════════════════════════════════
#  配置区
# ═══════════════════════════════════════════════════════════════════
DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
BASE_URL         = "https://api.deepseek.com"
MODEL_FLASH      = "deepseek-v4-flash"
MODEL_PRO        = "deepseek-v4-pro"
MAX_ROUNDS       = 2
PRO_THINKING     = "high"
# ═══════════════════════════════════════════════════════════════════

TZ_CST   = datetime.timezone(datetime.timedelta(hours=8))
now      = datetime.datetime.now(TZ_CST)
date_str = now.strftime("%Y年%m月%d日")
client   = OpenAI(api_key=DEEPSEEK_API_KEY, base_url=BASE_URL)


# ── Prompts ───────────────────────────────────────────────────────

FLASH_SYSTEM = f"""你是一名专注A股的地缘政治分析师，今天是{date_str}。

根据下方提供的【实时新闻搜索结果】，筛选过去24小时内对A股有实质影响的地缘政治事件，起草晨报。

【只保留以下类型，其余全部过滤】
- 中美贸易摩擦、关税、制裁、出口管制
- 台海局势、南海动态
- 俄乌战争（影响能源/粮食/通胀预期）
- 中东局势（影响原油价格）
- 朝鲜半岛动态
- 全球主要央行政策表态（影响风险偏好）
- 涉华国际外交事件（G7/联合国/WTO/APEC等）
- 全球供应链中断事件

无实质影响的事件一律不收录。若确无相关事件，明确输出：今日无重大地缘政治影响，市场情绪中性。

【严格按以下格式输出】

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 A股地缘政治晨报
{date_str} · 覆盖过去24小时
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【市场情绪总体判断】
利多/中性/利空/混合 — 一句话说明主要驱动因素

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【重要事件】（按影响度从高到低排列）

🔴 高影响
[事件名称]
- 发生时间：
- 核心内容：（不超过100字）
- A股影响：
  · 利多板块：
  · 利空板块：
  · 需关注板块：
- 持续性：短期（1-3天）/中期（1-2周）/长期观察

🟡 中影响
（同上格式）

🟢 低影响
[事件名称]：一句话概括，预计影响有限

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【板块影响矩阵】

| 板块 | 方向 | 逻辑 |
|------|------|------|
（只填有实质影响的板块；↑利多 ↓利空 →中性；无影响行删除）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【已过滤事件】
（搜索到但对A股无实质影响的事件，一句话概括）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
信源：（从搜索结果中列出主要参考来源）"""

PRO_SYSTEM = """你是A股地缘政治晨报的审核员。
只输出以下JSON，不得输出任何其他内容：

{
  "verdict": "approve 或 revise",
  "score": 整数0-100,
  "issues": [
    {
      "severity": "high 或 medium 或 low",
      "message": "问题描述",
      "fix": "给Flash的具体修改指令"
    }
  ],
  "must_fix": ["必须修改项，可为空数组"],
  "search_more": ["需要补充搜索的关键词，不需要则为空数组"]
}

审核标准：
1. 是否遗漏过去24小时内影响A股的重大地缘政治事件
2. 板块影响判断是否合理，是否过度推断
3. 因果链是否有明显逻辑错误
4. 是否混入了对A股无实质影响的噪音事件
5. 市场情绪总体判断是否与事件内容吻合

重要：如果你认为某个重大事件可能存在但搜索结果不足，
在 search_more 中列出需要补充搜索的英文或中文关键词（最多3个）。

score >= 80 且无 high 级别 issues → verdict 输出 approve
否则 → verdict 输出 revise"""

FLASH_REVISE_TMPL = """以下是晨报草稿、补充搜索结果和审核员修改意见。
严格按照 must_fix 和 issues 中的 fix 指令修改，结合补充搜索结果完善内容，保持原有格式。

【审核意见】
{review_json}

【补充搜索结果】
{extra_news}

【原稿】
{draft}

输出修改后的完整晨报："""

FLASH_REVISE_NO_EXTRA_TMPL = """以下是晨报草稿和审核员修改意见。
严格按照 must_fix 和 issues 中的 fix 指令修改，保持原有格式，不改无问题的部分。

【审核意见】
{review_json}

【原稿】
{draft}

输出修改后的完整晨报："""


# ── API 调用 ──────────────────────────────────────────────────────

def call_flash(messages: list) -> str:
    resp = client.chat.completions.create(
        model=MODEL_FLASH,
        messages=messages,
        temperature=0.3,
        max_tokens=4000,
    )
    return resp.choices[0].message.content.strip()

def call_pro(draft: str) -> dict:
    resp = client.chat.completions.create(
        model=MODEL_PRO,
        messages=[
            {"role": "system", "content": PRO_SYSTEM},
            {"role": "user",   "content": f"请审核以下晨报草稿：\n\n{draft}"},
        ],
        temperature=0.1,
        max_tokens=1500,
        extra_body={"reasoning_effort": PRO_THINKING},
    )
    raw = resp.choices[0].message.content.strip()
    s, e = raw.find("{"), raw.rfind("}") + 1
    if s == -1 or e == 0:
        return {"verdict": "approve", "score": 70, "issues": [],
                "must_fix": [], "search_more": [], "_raw": raw}
    try:
        return json.loads(raw[s:e])
    except json.JSONDecodeError:
        return {"verdict": "approve", "score": 70, "issues": [],
                "must_fix": [], "search_more": [], "_parse_error": raw[s:e]}


# ── 主流程 ────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--news-file",  required=True, help="主搜索结果文件路径")
    parser.add_argument("--extra-file", default="",   help="补充搜索结果文件路径（可选）")
    args = parser.parse_args()

    if not DEEPSEEK_API_KEY:
        print("❌ 未检测到 DEEPSEEK_API_KEY 环境变量")
        print("请执行：export DEEPSEEK_API_KEY='sk-xxxxxxxx'")
        sys.exit(1)

    # 读取新闻内容
    try:
        with open(args.news_file, "r", encoding="utf-8") as f:
            news_context = f.read().strip()
    except FileNotFoundError:
        print(f"❌ 找不到新闻文件：{args.news_file}")
        sys.exit(1)

    extra_news = ""
    if args.extra_file and os.path.exists(args.extra_file):
        with open(args.extra_file, "r", encoding="utf-8") as f:
            extra_news = f.read().strip()

    if extra_news:
        news_context = news_context + "\n\n【补充搜索结果】\n" + extra_news

    log = lambda msg: print(msg, flush=True)
    log(f"\n🔄 {date_str} A股地缘政治晨报生成中...\n")
    log(f"   新闻上下文：{len(news_context)} 字符\n")

    # Flash 初稿
    flash_msgs = [
        {"role": "system", "content": FLASH_SYSTEM},
        {"role": "user",   "content": f"【实时新闻搜索结果】\n{news_context}\n\n请根据以上内容起草晨报："},
    ]
    log("📝 [Flash] 正在起草初稿...")
    draft = call_flash(flash_msgs)
    log(f"   初稿完成，{len(draft)} 字符\n")

    # Pro 审核回环
    pending_search_more = []

    for rnd in range(1, MAX_ROUNDS + 1):
        log(f"🔍 [Pro] 审核中（第 {rnd}/{MAX_ROUNDS} 轮）...")
        review      = call_pro(draft)
        verdict     = review.get("verdict", "approve")
        score       = review.get("score", 0)
        issues      = review.get("issues", [])
        must_fix    = review.get("must_fix", [])
        search_more = review.get("search_more", [])

        log(f"   verdict={verdict}  score={score}  issues={len(issues)}  search_more={search_more}")

        if verdict == "approve":
            log(f"✅ [Pro] 审核通过（第 {rnd} 轮，score={score}）\n")
            break

        # 有补搜需求：先告知 SKILL.md，等补搜结果回来
        if search_more:
            pending_search_more = search_more
            log(f"🔎 [Pro] 需要补充搜索：{search_more}")
            # 输出特殊标记，SKILL.md 检测后执行补搜并重新调用本脚本
            keywords_str = "|".join(search_more)
            print(f"\n##SEARCH_MORE##{keywords_str}##END##", flush=True)
            # 同时输出当前草稿供参考（SKILL.md 可忽略或展示）
            return  # 退出，等 SKILL.md 补搜后重新调用

        if rnd == MAX_ROUNDS:
            log(f"⚠️  已达最大审核轮次（{MAX_ROUNDS}），输出当前版本\n")
            draft += f"\n\n⚠️ 已达最大审核轮次（{MAX_ROUNDS} 轮），当前版本未经完整审核，请人工复核"
            break

        # 无补搜需求，Flash 直接按意见修改
        log(f"✏️  [Flash] 按审核意见修改中...")
        revise_prompt = FLASH_REVISE_NO_EXTRA_TMPL.replace(
            "{review_json}", json.dumps(review, ensure_ascii=False, indent=2)
        ).replace("{draft}", draft)
        flash_msgs = [
            {"role": "system", "content": FLASH_SYSTEM},
            {"role": "user",   "content": revise_prompt},
        ]
        draft = call_flash(flash_msgs)
        log(f"   修改完成，{len(draft)} 字符\n")

    # 最终输出
    print("\n" + "═" * 60)
    print(draft)
    print("═" * 60 + "\n")


if __name__ == "__main__":
    main()
